package com.example.reelsautoswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AutoSwipeService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("reels_auto_swipe", MODE_PRIVATE) }
    private var receiverRegistered = false
    @Volatile private var foregroundPackage: String? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!prefs.getBoolean("running", false)) return
            val startedAt = prefs.getLong("started_at", System.currentTimeMillis())
            val runMs = prefs.getInt("run_minutes", 20).coerceAtLeast(1) * 60_000L
            if (System.currentTimeMillis() - startedAt >= runMs) {
                prefs.edit().putBoolean("running", false).apply()
                sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra("running", false))
                return
            }

            // Safety: never swipe other apps or the Android home/settings screen.
            if (foregroundPackage == INSTAGRAM_PACKAGE || foregroundPackage == FACEBOOK_PACKAGE) {
                swipeUp()
            }
            val interval = prefs.getInt("duration_seconds", 15).coerceIn(5, 600) * 1000L
            handler.postDelayed(this, interval)
        }
    }

    private val controlReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_CONTROL) return
            handler.removeCallbacks(tick)
            if (intent.getBooleanExtra("start", false) && prefs.getBoolean("running", false)) {
                val interval = prefs.getInt("duration_seconds", 15).coerceIn(5, 600) * 1000L
                handler.postDelayed(tick, interval)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!receiverRegistered) {
            val filter = IntentFilter(ACTION_CONTROL)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(controlReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(controlReceiver, filter)
            }
            receiverRegistered = true
        }
        if (prefs.getBoolean("running", false)) {
            handler.removeCallbacks(tick)
            val interval = prefs.getInt("duration_seconds", 15).coerceIn(5, 600) * 1000L
            handler.postDelayed(tick, interval)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        foregroundPackage = pkg
    }

    override fun onInterrupt() {
        handler.removeCallbacks(tick)
    }

    private fun swipeUp() {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.5f
        val path = Path().apply {
            moveTo(x, dm.heightPixels * 0.78f)
            lineTo(x, dm.heightPixels * 0.28f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (receiverRegistered) {
            unregisterReceiver(controlReceiver)
            receiverRegistered = false
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_CONTROL = "com.example.reelsautoswipe.CONTROL"
        const val ACTION_STATUS = "com.example.reelsautoswipe.STATUS"
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        private const val FACEBOOK_PACKAGE = "com.facebook.katana"
    }
}
