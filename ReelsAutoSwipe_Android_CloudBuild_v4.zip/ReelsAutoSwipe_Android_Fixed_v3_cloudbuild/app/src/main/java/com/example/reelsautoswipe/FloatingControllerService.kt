package com.example.reelsautoswipe

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingControllerService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var minimized = false
    private lateinit var status: TextView
    private lateinit var startStopButton: Button

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Controller ready"))
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Display over other apps first", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildPanel()
    }

    private fun buildPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(25, 28, 38))
        }
        val header = TextView(this).apply {
            text = "☰ REELS AUTO SWIPE"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), dp(6), dp(6), dp(10))
        }
        root.addView(header)
        header.setOnTouchListener(DragTouchListener())

        status = TextView(this).apply {
            text = "READY"
            setTextColor(Color.rgb(120, 230, 170))
            textSize = 12f
            setPadding(dp(6), dp(2), dp(6), dp(8))
        }
        root.addView(status)

        startStopButton = Button(this).apply {
            text = "▶ START"
            setOnClickListener {
                val prefs = getSharedPreferences("reels_auto_swipe", MODE_PRIVATE)
                val isRunning = prefs.getBoolean("running", false)
                if (isRunning) stopAutomation() else startAutomation()
            }
        }
        root.addView(startStopButton)

        val minimizeButton = Button(this).apply {
            text = "MINIMIZE"
            setOnClickListener {
                minimized = !minimized
                status.visibility = if (minimized) View.GONE else View.VISIBLE
                startStopButton.visibility = if (minimized) View.GONE else View.VISIBLE
                text = if (minimized) "SHOW CONTROLS" else "MINIMIZE"
                header.text = if (minimized) "☰ REELS • CONTROLLER" else "☰ REELS AUTO SWIPE"
            }
        }
        root.addView(minimizeButton)

        root.addView(Button(this).apply {
            text = "CLOSE PANEL"
            setOnClickListener {
                stopAutomation()
                stopSelf()
            }
        })

        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            dp(230), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(100)
        }
        panel = root
        wm.addView(root, params)
    }

    private fun startAutomation() {
        val prefs = getSharedPreferences("reels_auto_swipe", MODE_PRIVATE)
        prefs.edit().putBoolean("running", true).putLong("started_at", System.currentTimeMillis()).apply()
        sendControl(true)
        startStopButton.text = "■ END / STOP"
        status.text = "RUNNING • waiting for Reels"
        status.setTextColor(Color.rgb(120, 230, 170))
        updateNotification("Auto-swipe is enabled")
    }

    private fun stopAutomation() {
        getSharedPreferences("reels_auto_swipe", MODE_PRIVATE).edit().putBoolean("running", false).apply()
        sendControl(false)
        if (::startStopButton.isInitialized) startStopButton.text = "▶ START"
        if (::status.isInitialized) {
            status.text = "STOPPED"
            status.setTextColor(Color.rgb(255, 170, 120))
        }
        updateNotification("Auto-swipe stopped")
    }

    private fun sendControl(start: Boolean) {
        sendBroadcast(Intent(AutoSwipeService.ACTION_CONTROL).setPackage(packageName).putExtra("start", start))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = params ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = p.x; startY = p.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (event.rawX - downX).toInt()
                    p.y = startY + (event.rawY - downY).toInt()
                    panel?.let { wm.updateViewLayout(it, p) }
                    return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return false
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Reels Auto Swipe", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Reels Auto Swipe")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopAutomation()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "reels_auto_swipe_channel"
        private const val NOTIFICATION_ID = 7412
    }
}
