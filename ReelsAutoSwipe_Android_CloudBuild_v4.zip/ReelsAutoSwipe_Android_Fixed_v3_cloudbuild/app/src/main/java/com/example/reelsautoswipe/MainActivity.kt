package com.example.reelsautoswipe

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("reels_auto_swipe", MODE_PRIVATE) }
    private lateinit var durationInput: EditText
    private lateinit var runTimeInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 28, 26, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "REELS AUTO SWIPE"
            textSize = 25f
            gravity = Gravity.CENTER
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "Floating on-screen controller for Instagram and Facebook Reels."
            textSize = 15f
            setPadding(0, 12, 0, 18)
        }, matchWrap())

        durationInput = EditText(this).apply {
            hint = "Seconds per Reel (5–600)"
            inputType = 2
            setText(prefs.getInt("duration_seconds", 15).toString())
        }
        root.addView(durationInput, matchWrap())

        runTimeInput = EditText(this).apply {
            hint = "Total session minutes (1–1440)"
            inputType = 2
            setText(prefs.getInt("run_minutes", 20).toString())
        }
        root.addView(runTimeInput, matchWrap())

        root.addView(Button(this).apply {
            text = "1. Enable Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, matchWrap())

        root.addView(Button(this).apply {
            text = "2. Allow Display Over Other Apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    Toast.makeText(this@MainActivity, "Overlay permission is already enabled", Toast.LENGTH_SHORT).show()
                }
            }
        }, matchWrap())

        root.addView(Button(this).apply {
            text = "OPEN FLOATING CONTROLLER"
            setOnClickListener {
                val duration = durationInput.text.toString().toIntOrNull()
                val minutes = runTimeInput.text.toString().toIntOrNull()
                if (duration == null || duration !in 5..600 || minutes == null || minutes !in 1..1440) {
                    Toast.makeText(this@MainActivity, "Enter 5–600 seconds and 1–1440 minutes.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.edit().putInt("duration_seconds", duration)
                    .putInt("run_minutes", minutes).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Allow Display over other apps first.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    return@setOnClickListener
                }
                startService(Intent(this@MainActivity, FloatingControllerService::class.java))
                moveTaskToBack(true)
            }
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "Use: enable Accessibility and overlay permission, open the floating panel, then switch to Instagram or Facebook Reels. Swipes are timer-based and only run while one of those apps is in the foreground."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }
}
