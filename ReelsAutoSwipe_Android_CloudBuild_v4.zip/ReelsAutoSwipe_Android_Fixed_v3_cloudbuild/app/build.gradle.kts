plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.reelsautoswipe"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.reelsautoswipe"
        minSdk = 24
        // Keep target at 32 for broader sideload compatibility on mobile IDEs.
        targetSdk = 32
        versionCode = 3
        versionName = "3.0"
    }
}
