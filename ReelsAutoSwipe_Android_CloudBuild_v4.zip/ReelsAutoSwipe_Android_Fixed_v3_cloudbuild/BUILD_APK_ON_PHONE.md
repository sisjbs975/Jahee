# Build an installable APK using GitHub Actions (phone-only route)

This ZIP contains Android source code, not a prebuilt APK. The included GitHub Actions workflow can compile it in GitHub's cloud after the source is uploaded to a repository.

1. In a browser, sign in to GitHub and create a new repository named `ReelsAutoSwipe`. For easiest setup, make it **Public** (or use a private repository if your account permits Actions).
2. Extract this ZIP on your phone.
3. Open the new repository on GitHub in your browser. Use **Add file → Upload files** and upload the extracted project files, including the hidden `.github/workflows/build-apk.yml` file. If the mobile site hides upload options, enable **Desktop site** in the browser menu.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build Reels Auto Swipe APK** and tap **Run workflow** if it has not started automatically.
6. Wait for the run to finish. A green check means the build succeeded; a red X means the source needs fixing.
7. Open the successful run, scroll to **Artifacts**, and download `ReelsAutoSwipe-debug-apk`. Extract that downloaded artifact ZIP; inside is `app-debug.apk`.
8. Tap `app-debug.apk` to install. If Android asks, allow your browser or Files app to install unknown apps. Only install APKs from your own successful build.
9. Open the app and enable the requested Accessibility and display-over-other-apps permissions.

Notes:
- This workflow has not been run here, so the build is not guaranteed to succeed until GitHub runs it.
- A debug APK is suitable for testing/sideloading; it is not a Play Store release.
- Upload all project files and folders, preserving their paths. If GitHub's mobile uploader cannot upload the `.github` folder, use GitHub's Desktop site or another upload method that preserves hidden folders.
